import requests
from bs4 import BeautifulSoup
import pdfplumber
from sentence_transformers import SentenceTransformer
from app.storage import get_stored_content
from cleantext import clean

model = SentenceTransformer('all-MiniLM-L6-v2')

def process_url_content(url: str) -> str:
    response = requests.get(url)
    if response.status_code != 200:
        return None
    soup = BeautifulSoup(response.text, 'html.parser')
    return ' '.join(soup.stripped_strings)

def process_pdf_content(file) -> str:
    with pdfplumber.open(file) as pdf:
        text = ''
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + '\n'  # Preserve line breaks

    # Use clean-text for standard cleaning
    cleaned_text = clean(
        text,
        fix_unicode=True,              # Replace unicode symbols with ASCII equivalents
        to_ascii=True,                 # Convert non-ASCII characters to closest ASCII equivalents
        lower=False,                   # Convert text to lowercase
        no_line_breaks=True,           # Remove line breaks
        no_urls=True,                  # Remove URLs
        no_emails=True,                # Remove emails
        no_phone_numbers=True,         # Remove phone numbers
        no_numbers=False,              # Remove all numbers
        no_digits=False,               # Remove digits
        no_currency_symbols=True,      # Remove currency symbols
        no_punct=False,                # Remove punctuations
        replace_with_punct="",         # Replace punctuations with space or custom string
        replace_with_url="",           # Replace URLs with space or custom string
        replace_with_email="",         # Replace emails with space or custom string
        replace_with_phone_number="",  # Replace phone numbers with space or custom string
        replace_with_currency_symbol="", # Replace currency symbols with space or custom string
        lang="en"                      # Specify language for stopwords removal
    )
    
    return cleaned_text


def get_response(chat_id: str, question: str) -> str:
    content = get_stored_content(chat_id)
    if not content:
        return None
    question_embedding = model.encode(question, convert_to_tensor=True)
    content_embeddings = model.encode(content, convert_to_tensor=True)
    
    # Calculate cosine similarity using SentenceTransformer's utility function
    model.similarity_fn_name = "cosine"
    cosine_scores = model.similarity(question_embedding, content_embeddings)

    # Find the content with the highest similarity score
    best_index = cosine_scores.argmax().item()
    return content[best_index]
    