import uuid
storage = {}

def store_content(content: str) -> str:
    chat_id = str(uuid.uuid4())
    storage[chat_id] = content.split('. ')
    return chat_id

def get_stored_content(chat_id: str) -> list:
    return storage.get(chat_id)
